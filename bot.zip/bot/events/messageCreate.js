const config = require('../config.js');

module.exports = (client, message) => {
  if (message.author.bot || !message.content.startsWith(config.prefix)) return;

  const args = message.content.slice(config.prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  let cmdFile = client.commands.get(command);
  if (cmdFile) cmdFile.run(client, message, args);
};
