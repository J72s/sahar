const { joinVoiceChannel } = require('@discordjs/voice');
const allowedUsers = require("../allowed.json").allowed;

module.exports = {
    names: {
        list: ["vc"]
    },
    run: async (client, message, args) => {
        try {
            if (!allowedUsers.includes(message.author.id)) {
                message.channel.send("You don't have permission to use this command.");
                return;
            }

            if (args.length < 1) {
                message.channel.send("Please provide a voice channel ID.");
                return;
            }

            const channelId = args[0];
            const channel = client.channels.cache.get(channelId);

            if (!channel || channel.type !== 'GUILD_VOICE') {
                message.channel.send("Please provide a valid voice channel ID.");
                return;
            }

            // Join the voice channel
            const connection = joinVoiceChannel({
                channelId: channel.id,
                guildId: channel.guild.id,
                adapterCreator: channel.guild.voiceAdapterCreator,
                selfDeaf: false,
                selfMute: true
            });

            message.channel.send(`Joined voice channel: ${channel.name}`);

            // Function to toggle mute state
            const toggleMute = async () => {
                if (connection.state.status !== 'ready') return; // Check if connection is ready

                const newState = !connection.state.subscription.mute;
                await connection.subscription.mute(newState);
                message.channel.send(`Toggled mute state to ${newState ? "ON" : "OFF"}`);
            };

            // Alternate mute state every 30 minutes
            setInterval(toggleMute, 30 * 60 * 1000); // 30 minutes in milliseconds

        } catch (error) {
            console.error("Error occurred during the event:", error);
            message.channel.send("An error occurred while trying to join the voice channel.");
        }
    }
};
